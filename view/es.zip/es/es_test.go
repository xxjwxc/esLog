package es

import (
	"encoding/json"
	"fmt"
	"log"
	"testing"
	"time"

	"git.ezbuy.me/ezbuy/oplogger/rpc/oplogger"
	"gopkg.in/olivere/elastic.v5"

	"git.ezbuy.me/ezbuy/oplogger/config"
)

func TestEsAdd(m *testing.T) {
	config.Config.ElasticSearch.Url = "http://192.168.199.99:9200/"
	config.Config.ElasticSearch.Index = "ezbuy_wms_log"

	es := GetClient()

	var eslog ESLog
	eslog.TraceID = "traceid"

	//应用/服务的唯一标识： 用来确定日志产生的应用服务器的唯一标识(可以细分)
	eslog.Topic = "topic"
	eslog.Bundle = "bundle"
	eslog.Pid = "pid"

	//用户信息
	eslog.UserID = "userid"
	eslog.UserName = "username"

	//业务唯一标识
	eslog.IdType = 2
	eslog.Id = `json:"id"`
	eslog.SubID = `json:"sub_id"`

	//时间列表
	eslog.BeginTime = time.Now()
	eslog.EndTime = time.Now()
	eslog.CreatTime = time.Now()

	//事件列表，描述
	eslog.ELevel = oplogger.ELogLevel_EOperate
	//类型，1：自动，2：手动
	eslog.EType = oplogger.EEventType_EEManual
	eslog.EDesc = `json:"edesc"`

	//变化值序列
	eslog.IType = 111111
	//变化前值
	eslog.IOriginal = `ioriginal`
	//变化后值
	eslog.ITranslation = `itranslation`
	//变化值
	eslog.IVaiable = "ivaiable"

	//备注
	eslog.Desc = `json:"desc"`

	//预留字段
	eslog.DString = `json:"dstring"`
	eslog.DInt = 456
	eslog.DDate = time.Now()

	var tmp []interface{}
	for i := 0; i < 3; i++ {
		eslog.DInt += 111
		tmp = append(tmp, eslog)
	}

	b := es.BulkAdd(config.Config.ElasticSearch.Index,
		config.Config.ElasticSearch.Index, "", tmp)
	if !b {
		fmt.Println(es.Err)
	}

	// var eslogs []ESLog
	// es.Search(config.Config.ElasticSearch.Index,
	// 	config.Config.ElasticSearch.Index, `{"query":{"match_all":{}}}`, &eslogs)

	// fmt.Println(eslogs)
}

func TestSearch(t *testing.T) {

	config.Config.ElasticSearch.Url = "http://192.168.199.99:9200/"
	config.Config.ElasticSearch.Index = "ezbuy_wms_log"

	es := GetClient()

	// var ws []map[string]interface{}
	// b := es.SearchMap(config.Config.ElasticSearch.Index,
	// 	config.Config.ElasticSearch.Index, `{"query":{"match_all":{}}}`, &ws)
	// fmt.Println(b)
	// for _, v := range ws {
	// 	fmt.Println(v)
	// }
	// fmt.Println(len(ws))

	// source := map[string]interface{}{
	// 	"from": 0,
	// 	"size": 1,
	// 	"query": map[string]interface{}{
	// 		"filtered": map[string]interface{}{
	// 			"query": map[string]interface{}{
	// 				"bool": map[string]interface{}{
	// 					"must": []interface{}{
	// 						map[string]interface{}{
	// 							"match": map[string]interface{}{
	// 								"itype": 666,
	// 							},
	// 						},
	// 						map[string]interface{}{
	// 							"match": map[string]interface{}{
	// 								"dint": 456,
	// 							},
	// 						},
	// 					},
	// 				},
	// 			},
	// 			"filter": map[string]interface{}{
	// 				"and": []interface{}{
	// 					map[string]interface{}{
	// 						"range": map[string]interface{}{
	// 							"creat_time": map[string]interface{}{
	// 								"gte": time.Now().AddDate(0, 0, -1),
	// 								"lte": time.Now(),
	// 							},
	// 						},
	// 					},
	// 					map[string]interface{}{
	// 						"range": map[string]interface{}{
	// 							"begin_time": map[string]interface{}{
	// 								"gte": time.Now().AddDate(0, 0, -1),
	// 								"lte": time.Now(),
	// 							},
	// 						},
	// 					},
	// 				},
	// 			},
	// 		},
	// 	},
	// }

	//年龄大于30岁的
	source := elastic.NewBoolQuery()
	source = source.Must(elastic.NewTermQuery("itype", 666))

	// q := NewBoolQuery()
	// q = q.Must(NewTermQuery("tag", "wow"))
	//source = source.MustNot(elastic.NewRangeQuery("age").From(10).To(20))
	source = source.Filter(elastic.NewTermQuery("dint", 456))
	source = source.Should(elastic.NewTermQuery("tag", "sometag"), elastic.NewTermQuery("tag", "sometagtag"))
	source = source.Boost(10)
	source = source.DisableCoord(true)
	source = source.QueryName("Test")
	src, _ := source.Source()

	//source.Filter(elastic.NewRangeQuery("age").Gt(30))

	data1, _ := json.Marshal(src)
	fmt.Println(string(data1))
	//query := elastic.NewSearchSource().Query(elastic.NewMatchAllQuery()).From(0).Size(1)
	//`{"query":{"match_all":{}}}`
	var eslog []ESLog
	es.Search(config.Config.ElasticSearch.Index,
		config.Config.ElasticSearch.Index, src, func(e []byte) error {
			var tmp ESLog
			err := json.Unmarshal(e, &tmp)
			if err != nil {
				log.Println(err)
			} else {
				eslog = append(eslog, tmp)
			}
			return err
		})
	fmt.Println(eslog)
}
